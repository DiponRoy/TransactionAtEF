﻿using Db;
using Db.Table;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;
using Test.Db;

namespace Logic
{
    public class StudentUpdateLogic
    {
        public const int CommitSize = 2;           /*must increase in prod*/
        public const string UpdatePart = "-updated";
        public IUmsDbContext DbContext;

        public StudentUpdateLogic(IUmsDbContext dbContext)
        {
            DbContext = dbContext;
        }

        /*transection not working*/
        //public void UpdateAndSave(List<Student> students)
        //{
        //    using (var transaction = DbContext.Database.BeginTransaction())
        //    {
        //        int commitCount = 0;
        //        try
        //        {
        //            foreach (Student student in students)
        //            {
        //                ++commitCount;
        //                student.Name = student.Name + UpdatePart;
        //                DbContext.SaveChanges();
        //                if (commitCount % CommitSize == 0)
        //                {
        //                    commitCount = 0;
        //                    var newDbContext = new UmsDb(DbContext.Options);
        //                    newDbContext.Database.UseTransaction(transaction.GetDbTransaction());
        //                    DbContext = newDbContext;
        //                }
        //            }

        //            transaction.Commit();
        //        }
        //        catch (Exception exception)
        //        {
        //            transaction.Rollback();
        //            throw new TransactionException("Error to update all student", exception);
        //        }
        //    }
        //}


        public void UpdateAndSave(List<Student> students)
        {
            using (var transaction = DbContext.Database.BeginTransaction())
            {
                int commitCount = 0;
                try
                {
                    foreach (Student student in students)
                    {
                        ++commitCount;
                        student.Name = student.Name + UpdatePart;
                        DbContext.SaveChanges();
                        if (commitCount % CommitSize == 0)
                        {
                            commitCount = 0;
                            var newDbContext = new UmsDb(DbContext.Options);
                            newDbContext.Database.UseTransaction(transaction.GetDbTransaction());
                            DbContext = newDbContext;
                        }
                    }

                    transaction.Commit();
                }
                catch (Exception exception)
                {
                    transaction.Rollback();
                    throw new TransactionException("Error to update all student", exception);
                }
            }
        }

        public void LargeAdd(List<Student> students)
        {
            DbContext.ChangeTracker.AutoDetectChangesEnabled = false;
            using (var transaction = DbContext.Database.BeginTransaction())
            {
                int commitCount = 0;
                try
                {
                    foreach (Student student in students)
                    {
                        DbContext.Students.Add(student);
                        DbContext.SaveChanges();
                        if (commitCount % CommitSize == 0)
                        {
                            commitCount = 0;
                            var newDbContext = new UmsDb(DbContext.Options);
                            newDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
                            newDbContext.Database.UseTransaction(transaction.GetDbTransaction());
                            DbContext = newDbContext;
                        }
                    }

                    transaction.Commit();
                }
                catch (Exception exception)
                {
                    transaction.Rollback();
                    throw new TransactionException("Error to update all student", exception);
                }
            }
        }
    }
}
