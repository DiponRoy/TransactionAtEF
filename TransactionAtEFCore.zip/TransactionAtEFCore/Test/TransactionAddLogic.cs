﻿using Db;
using Db.Table;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Storage;
using System;
using System.Collections.Generic;
using System.Text;
using System.Transactions;
using Test.Db;

namespace Logic
{
    public class TransactionAddLogic
    {
        public readonly int CommitSize;
        public IUmsDbContext DbContext;

        public TransactionAddLogic(IUmsDbContext dbContext, int batchSize)
        {
            DbContext = dbContext;
            DbContext.ChangeTracker.AutoDetectChangesEnabled = false;

            CommitSize = batchSize;
        }

        public void Add(List<Student> students)
        {
            using (var transaction = DbContext.Database.BeginTransaction())
            {
                try
                {
                    Add(students, transaction);
                    transaction.Commit();
                }
                catch (Exception exception)
                {
                    transaction.Rollback();
                    throw new TransactionException("Error to add all student", exception);
                }
            }
        }

        public void DeleteAndAdd(List<Student> students)
        {
            using (var transaction = DbContext.Database.BeginTransaction())
            {
                try
                {
                    DbContext.CleanStudent();
                    Add(students, transaction);
                    transaction.Commit();
                }
                catch (Exception exception)
                {
                    transaction.Rollback();
                    throw new TransactionException("Error to add all student", exception);
                }
            }
        }

        private void Add(List<Student> students, IDbContextTransaction transaction)
        {
            int commitCount = 0;
            foreach (Student student in students)
            {
                DbContext.Students.Add(student);
                DbContext.SaveChanges();
                if (commitCount % CommitSize == 0)
                {
                    commitCount = 0;
                    var newDbContext = new UmsDb(DbContext.Options);
                    newDbContext.ChangeTracker.AutoDetectChangesEnabled = false;
                    newDbContext.Database.UseTransaction(transaction.GetDbTransaction());
                    DbContext = newDbContext;
                }
            }
        }
    }
}
