﻿using Db;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using System;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;

namespace Test.Db
{
    public class UmsDb : UmsDbContext
    {
        public UmsDb() : base()
        {
        }

        public UmsDb(DbContextOptions options) : base(options)
        {
        }

        public UmsDb(DbConnection connection) : base(connection)
        {
        }


        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

            if (Connection != null)
            {
                optionsBuilder.UseSqlServer(Connection);
                return;
            }

            if (Options != null)
            {
                return;
            }

            /*
             * appsettings.json read:
             * https://blog.bitscry.com/2017/05/30/appsettings-json-in-net-core-console-app/
             * 
             * share connectionstrings.json between projects:
             * https://andrewlock.net/sharing-appsettings-json-configuration-files-between-projects-in-asp-net-core/
             * https://stackoverflow.com/questions/35527144/how-to-get-bin-folder-in-asp-net-core-1-0
             */
            var builder = new ConfigurationBuilder()
                .AddJsonFile(Path.Combine(Directory.GetCurrentDirectory(), "appsettings.json"), optional: true);
            IConfigurationRoot configuration = builder.Build();
            //optionsBuilder.UseSqlServer(configuration.GetConnectionString("UmsDbConnection"));


            DbConnection connection = new SqlConnection(configuration.GetConnectionString("UmsDbConnection"));


            optionsBuilder.UseSqlServer(connection);
            base.OnConfiguring(optionsBuilder);
            Options = optionsBuilder.Options;
            Connection = connection;
        }
    }
}
