﻿/*
 * CR Title         : Admin panel
 * Start Date       : 05-Jul-2019
 * Version          : 2.0
 * Author/Developer : dipon
 * Purpose          : CFS entity framework db
*/

using System;
using Db.Table;
using Db.Configuration;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Infrastructure;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using System.Data.Common;

namespace Db
{
    public abstract class UmsDbContext : DbContext, IUmsDbContext
    {
        public DbContextOptions Options { get; protected set; }
        public DbConnection Connection { get; protected set; }


        public virtual DbSet<Student> Students { get; set; }
        public virtual DbSet<Address> Addresses { get; set; }


        public UmsDbContext(DbContextOptions options): base(options)
        {
            Options = options;
        }

        public UmsDbContext(DbConnection connection)
        {
            Connection = connection;
        }

        protected UmsDbContext() : base()
        {
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.ApplyConfiguration(new AddressConfig());
            modelBuilder.ApplyConfiguration(new StudentConfig());
        }

        public void Clean()
        {
            CleanStudent();
            Database.ExecuteSqlCommand(@"DELETE FROM [Address];");
        }

        public void CleanStudent()
        {
            Database.ExecuteSqlCommand(@"DELETE FROM [Student];");
        }
    }

    public interface IUmsDbContext : IDisposable
    {
        DbContextOptions Options { get; }
        DbConnection Connection { get; }


        DbSet<Student> Students { get; set; }
        DbSet<Address> Addresses { get; set; }

        DatabaseFacade Database { get; }
        ChangeTracker ChangeTracker { get; }
        int SaveChanges();

        void Clean();
        void CleanStudent();
    }
}
